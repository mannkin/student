# kod nie jest poprawny skladniowo, Syntax error

f (x > y): # invalid syntax
    result = x;
else:
    result = y;

for i in "qwerty": if ord(i) < 100: print i

for i in "axby": print ord(i) if ord(i) < 100 else i
x = 2 ; y = 3 ;
if (x > y):
    result = x;
else:
    result = y;

for i in "qwerty": if ord(i) < 100: print i

for i in "axby": print ord(i) if ord(i) < 100 else i

