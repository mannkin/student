# blad przy 'x, y = 1, 2, 3' brakuje zmiennej dla 3
# blad przy 'X = 1, 2, 3 ; X[1] = 4' nie mozna zmieniac krotki
# blad przy 'X = [1, 2, 3] ; X[3] = 4' brak X[3] out of range
# blad przy 'X = "abc" ; X.append("d")' string nie ma append
# blad przy 'map(pow, range(8))' pow ma za malo argumentow, i
 
L = [3, 5, 4] ; L = L.sort()

x, y = 1, 2, 3

X = 1, 2, 3 ; X[1] = 4

X = [1, 2, 3] ; X[3] = 4

X = "abc" ; X.append("d")

map(pow, range(8))


