for number in range(30) :
	if number % 3 != 0 :
		print(number)
