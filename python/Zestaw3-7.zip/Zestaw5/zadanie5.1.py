import rekurencja
# import rekurencja as rek
# from rekurencja import *
# from rekurencja import factorial
# from rekurencja import fibonacci as fib

print(rekurencja.factorial(6))
print(rekurencja.fibonacci(5))
